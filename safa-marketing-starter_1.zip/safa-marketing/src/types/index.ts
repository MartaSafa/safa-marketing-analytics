// src/types/index.ts

export type Brand = 'all' | 'audi' | 'vw' | 'skoda'

export interface MetaCampaign {
  id: string
  date: string
  campaign_id: string
  campaign_name: string
  status: 'ACTIVE' | 'PAUSED' | 'DELETED'
  objective: string
  brand: string
  spend: number
  impressions: number
  clicks: number
  leads: number
}

export interface GoogleCampaign {
  id: string
  date: string
  campaign_id: string
  campaign_name: string
  status: 'ENABLED' | 'PAUSED' | 'REMOVED'
  campaign_type: 'SEARCH' | 'DISPLAY' | 'VIDEO' | 'PERFORMANCE_MAX'
  brand: string
  spend: number
  impressions: number
  clicks: number
  conversions: number
  quality_score: number | null
}

export interface Budget {
  id: string
  year: number
  month: number
  amount: number
  notes?: string
}

export interface KPIs {
  leads: number
  opportunities: number
  offers: number
  orders: number
  totalSpend: number
  cpl: number
  cpo: number
  metaSpend: number
  googleSpend: number
  metaLeads: number
  googleLeads: number
}

export interface DateFilter {
  from: string  // YYYY-MM-DD
  to: string
}

export interface Filters {
  date: DateFilter
  brand: Brand
  model?: string
}
