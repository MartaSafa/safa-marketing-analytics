// src/app/api/sync/route.ts
// Vercel Cron Job — se ejecuta automáticamente cada noche a las 3:00
// También puedes llamarlo manualmente: GET /api/sync?secret=TU_CRON_SECRET

import { NextRequest, NextResponse } from 'next/server'
import { createServiceClient } from '@/lib/supabase/server'

// ─── Helpers de Meta ─────────────────────────────────────────

async function syncMeta(supabase: ReturnType<typeof createServiceClient>, date: string) {
  const accountId = process.env.META_AD_ACCOUNT_ID
  const token     = process.env.META_ACCESS_TOKEN

  // Trae insights por campaña del día anterior
  const url = `https://graph.facebook.com/v19.0/${accountId}/insights?` + new URLSearchParams({
    fields:        'campaign_id,campaign_name,status,objective,spend,impressions,clicks,actions',
    time_range:    JSON.stringify({ since: date, until: date }),
    level:         'campaign',
    access_token:  token!,
  })

  const res  = await fetch(url)
  const data = await res.json()

  if (!data.data) throw new Error(JSON.stringify(data))

  const rows = data.data.map((c: any) => ({
    date,
    campaign_id:   c.campaign_id,
    campaign_name: c.campaign_name,
    status:        c.status || 'UNKNOWN',
    objective:     c.objective,
    brand:         detectBrand(c.campaign_name),
    spend:         parseFloat(c.spend || '0'),
    impressions:   parseInt(c.impressions || '0'),
    clicks:        parseInt(c.clicks || '0'),
    leads:         extractAction(c.actions, 'lead'),
  }))

  const { error } = await supabase.from('meta_campaigns').upsert(rows, {
    onConflict: 'date,campaign_id',
  })

  if (error) throw error
  return rows.length
}

// ─── Helpers de Google ───────────────────────────────────────

async function syncGoogle(supabase: ReturnType<typeof createServiceClient>, date: string) {
  // Google Ads API usa OAuth2 — primero refrescamos el access token
  const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      client_id:     process.env.GOOGLE_ADS_CLIENT_ID!,
      client_secret: process.env.GOOGLE_ADS_CLIENT_SECRET!,
      refresh_token: process.env.GOOGLE_ADS_REFRESH_TOKEN!,
      grant_type:    'refresh_token',
    }),
  })
  const { access_token } = await tokenRes.json()

  const customerId    = process.env.GOOGLE_ADS_CUSTOMER_ID!.replace(/-/g, '')
  const developerToken= process.env.GOOGLE_ADS_DEVELOPER_TOKEN!

  // Google Ads Query Language (GAQL)
  const query = `
    SELECT
      campaign.id, campaign.name, campaign.status, campaign.advertising_channel_type,
      metrics.cost_micros, metrics.impressions, metrics.clicks, metrics.conversions,
      metrics.average_quality_score
    FROM campaign
    WHERE segments.date = '${date}'
    AND campaign.status != 'REMOVED'
  `

  const res = await fetch(
    `https://googleads.googleapis.com/v16/customers/${customerId}/googleAds:search`,
    {
      method: 'POST',
      headers: {
        Authorization:         `Bearer ${access_token}`,
        'developer-token':     developerToken,
        'Content-Type':        'application/json',
      },
      body: JSON.stringify({ query }),
    }
  )
  const data = await res.json()
  if (!data.results) throw new Error(JSON.stringify(data))

  const rows = data.results.map((r: any) => ({
    date,
    campaign_id:   r.campaign.id,
    campaign_name: r.campaign.name,
    status:        r.campaign.status,
    campaign_type: r.campaign.advertisingChannelType,
    brand:         detectBrand(r.campaign.name),
    spend:         parseFloat(r.metrics.costMicros || '0') / 1_000_000,
    impressions:   parseInt(r.metrics.impressions || '0'),
    clicks:        parseInt(r.metrics.clicks || '0'),
    conversions:   parseFloat(r.metrics.conversions || '0'),
    quality_score: r.metrics.averageQualityScore || null,
  }))

  const { error } = await supabase.from('google_campaigns').upsert(rows, {
    onConflict: 'date,campaign_id',
  })

  if (error) throw error
  return rows.length
}

// ─── Utilities ───────────────────────────────────────────────

function detectBrand(name: string): string {
  const n = name.toLowerCase()
  if (n.includes('audi'))  return 'audi'
  if (n.includes('vw') || n.includes('volkswagen') || n.includes('golf') ||
      n.includes('polo') || n.includes('tiguan')) return 'vw'
  if (n.includes('skoda') || n.includes('škoda') || n.includes('octavia') ||
      n.includes('kodiaq')) return 'skoda'
  return 'multi'
}

function extractAction(actions: any[], type: string): number {
  if (!actions) return 0
  const a = actions.find((x: any) => x.action_type === type)
  return a ? parseInt(a.value || '0') : 0
}

// ─── Handler principal ───────────────────────────────────────

export async function GET(req: NextRequest) {
  // Verifica el secret para evitar llamadas no autorizadas
  const secret = req.nextUrl.searchParams.get('secret') ||
                 req.headers.get('authorization')?.replace('Bearer ', '')

  if (secret !== process.env.CRON_SECRET) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const yesterday = new Date()
  yesterday.setDate(yesterday.getDate() - 1)
  const date = yesterday.toISOString().split('T')[0] // YYYY-MM-DD

  const supabase = createServiceClient()
  const results: Record<string, any> = {}

  // Meta
  try {
    results.meta = { records: await syncMeta(supabase, date), status: 'ok' }
    await supabase.from('sync_log').insert({ source: 'meta', status: 'ok', records: results.meta.records })
  } catch (err: any) {
    results.meta = { status: 'error', message: err.message }
    await supabase.from('sync_log').insert({ source: 'meta', status: 'error', error_msg: err.message })
  }

  // Google
  try {
    results.google = { records: await syncGoogle(supabase, date), status: 'ok' }
    await supabase.from('sync_log').insert({ source: 'google', status: 'ok', records: results.google.records })
  } catch (err: any) {
    results.google = { status: 'error', message: err.message }
    await supabase.from('sync_log').insert({ source: 'google', status: 'error', error_msg: err.message })
  }

  return NextResponse.json({ date, ...results })
}
