'use client'
// src/app/login/page.tsx
import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { useRouter, useSearchParams } from 'next/navigation'

export default function LoginPage() {
  const router = useRouter()
  const params = useSearchParams()
  const domainError = params.get('error') === 'domain'

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const supabase = createClient()

  // Login con email + contraseña
  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) { setError('Credenciales incorrectas. Inténtalo de nuevo.'); setLoading(false) }
    else router.push('/dashboard')
  }

  // Login con Google Workspace SSO
  async function handleGoogle() {
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${location.origin}/auth/callback`,
        queryParams: { hd: 'safamotor.es' }, // restringe a dominio corporativo
      },
    })
  }

  return (
    <div className="min-h-screen bg-bg flex items-center justify-center p-4">
      <div className="bg-surface rounded-[14px] border border-border p-7 w-full max-w-[320px] shadow-sm">
        {/* Logo */}
        <div className="w-10 h-10 bg-primary rounded-[11px] flex items-center justify-center mx-auto mb-3">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round">
            <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
          </svg>
        </div>
        <h1 className="text-[15px] font-medium text-t1 text-center">Marketing Analytics</h1>
        <p className="text-[11px] text-t2 text-center mt-1 mb-5">Grupo Safamotor · Concesionarios VAG</p>

        {domainError && (
          <div className="bg-red-50 text-danger text-[11px] rounded-lg p-2.5 mb-4 text-center">
            Solo se permiten cuentas <strong>@safamotor.es</strong>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-3">
          <div>
            <label className="block text-[11px] font-medium text-t1 mb-1">Correo electrónico</label>
            <input
              type="email" required value={email} onChange={e => setEmail(e.target.value)}
              placeholder="jgarcia@safamotor.es"
              className="w-full border border-border rounded-lg px-3 py-2 text-[12px] text-t1 outline-none focus:border-primary focus:ring-2 focus:ring-primary/10"
            />
          </div>
          <div>
            <label className="block text-[11px] font-medium text-t1 mb-1">Contraseña</label>
            <input
              type="password" required value={password} onChange={e => setPassword(e.target.value)}
              className="w-full border border-border rounded-lg px-3 py-2 text-[12px] text-t1 outline-none focus:border-primary focus:ring-2 focus:ring-primary/10"
            />
          </div>
          {error && <p className="text-[11px] text-danger text-center">{error}</p>}
          <button
            type="submit" disabled={loading}
            className="w-full bg-primary text-white rounded-lg py-2.5 text-[12px] font-medium hover:bg-blue-700 transition-colors disabled:opacity-60"
          >
            {loading ? 'Entrando...' : 'Iniciar sesión →'}
          </button>
        </form>

        <div className="flex items-center gap-2 my-3">
          <div className="flex-1 h-px bg-border"/>
          <span className="text-[10px] text-t3">o</span>
          <div className="flex-1 h-px bg-border"/>
        </div>

        <button
          onClick={handleGoogle}
          className="w-full bg-surface border border-border rounded-lg py-2 text-[12px] text-t1 flex items-center justify-center gap-2 hover:bg-bg transition-colors"
        >
          <svg width="14" height="14" viewBox="0 0 24 24">
            <path fill="#EA4335" d="M5.3 12a6.8 6.8 0 0 1 .2-1.7L2.8 8.5A11.5 11.5 0 0 0 2 12c0 1.3.2 2.5.7 3.5l2.7-2.1A6.8 6.8 0 0 1 5.3 12z"/>
            <path fill="#FBBC05" d="M12 5.4a6.6 6.6 0 0 1 4.2 1.5l2.2-2.2A11 11 0 0 0 12 2C8.3 2 5 4.1 3.2 7.1l2.7 2.2A6.6 6.6 0 0 1 12 5.4z"/>
            <path fill="#34A853" d="M12 18.6a6.6 6.6 0 0 1-6.1-4.1L3.2 16.9C5 19.9 8.3 22 12 22a10.9 10.9 0 0 0 7.4-2.8l-2.6-2A6.6 6.6 0 0 1 12 18.6z"/>
            <path fill="#4285F4" d="M21.8 12c0-.7-.1-1.4-.2-2H12v4h5.5a4.8 4.8 0 0 1-2 3.1l2.6 2A10.9 10.9 0 0 0 21.8 12z"/>
          </svg>
          Entrar con Google Workspace
        </button>
      </div>
    </div>
  )
}
